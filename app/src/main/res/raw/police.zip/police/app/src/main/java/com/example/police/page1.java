package com.example.police;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;

public class page1 extends AppCompatActivity {

    private Spinner villageSpinner;
    private Spinner districtSpinner;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page1);

        villageSpinner = findViewById(R.id.village);
        districtSpinner = findViewById(R.id.district);


        // Array of states
        String[] district = new String[]{"ARIYALUR", "CHENGALPATTU", "CHENNAI", "COIMBATORE", "CUDDALORE", "DHARMAPURI",
                "DINDIGUL", "ERODE", "KALLAKURICHI", "KANCHEEPURAM", "KANYAKUMARI", "KARUR", "KRISHNAGIRI", "MADURAI",
                "NAGAPATTINAM", "NAMAKKAL", "NILGIRIS", "PERAMBALUR", "PUDUKKOTTAI", "RAMANATHAPURAM", "RANIPET", "SALEM",
                "SIVAGANGA", "TENKASI", "THANJAVUR", "THENI", "THOOTHUKUDI (TUTICORIN)", "TIRUCHIRAPPALLI", "TIRUNELVELI", "TIRUPATHUR",
                "TIRUPPUR", "TIRUVALLUR", "TIRUVANNAMALAI", "TIRUVARUR", "VELLORE", "VILUPPURAM", "VIRUDHUNAGAR"};



        // Setting up the array adapter for states
        ArrayAdapter<String> stateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, district);
        stateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        districtSpinner.setAdapter(stateAdapter);

        // Set listener for state selection
        districtSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateDistricts(district[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });
    }

    private void updateDistricts(String district) {
        // Assuming each state has a predefined list of districts
        String[] villages;
        switch (district) {
            case "ARIYALUR":
                villages = new String[]{"Adhanur", "Ayyanur", "Bhuvanagiri", "Dharanallur", "Egaiyur", "Elakurichi",
                        "Gangaikondan", "Kannapadi", "Kattur", "Kudikkadu", "Maruvathur",
                        "Melakurichi", "Peraiyur", "Periyakurichi", "Poolambadi", "Pudur", "Salukkai", "Sendurai", "Sithali", "Thennilai"};
                break;
            case "CHENGALPATTU":
                villages = new String[]{"Adigathur", "Akkarai", "Alakuppam", "Alapakkam", "Alathur", "Alinjivakkam", "Alliambakkam", "Aluthur",
                        "Ammanambakkam", "Ammanampakkam", "Ammanankuppam", "Anangur", "Anjur", "Annur", "Anumanthapuram", "Arasur", "Arugavoor",
                        "Asarkunnam", "Ashokapuram", "Athivakkam", "Athur", "Attupattu", "Avalur", "Ayankaranai", "Ayathur", "Ayyampettai",
                        "Balaramapuram", "Balasingapuram", "Balayathumangalam", "Bargur", "Bhakthavatsalam Nagar", "Bhuvanagiri", "Brahmadesam",
                        "Budur", "Chellaperambakkam", "Chembarambakkam", "Chengalpattu", "Chettipunyam", "Chettiyapattu", "Chinnakavanam", "Chinnamiram",
                        "Chitlapakkam", "Chittar", "Dadapuram", "Dalavoi", "Dalavoy Chithamur", "Datchinamurthy Nagar", "Edapalayam", "Eduthavainallur", "Eechangadu",
                        "Eguvarpalayam", "Elavur", "Enathur", "Ernavoor", "Erumbur", "Erungalore", "Ezhichur", "Gandhi Nagar", "Gandhi Nagar"};
                break;
            case"CHENNAI":
                villages = new String[]{"Alappuzha", "Ernakulam", "Idukki", "Kannur", "Kasaragod", "Kollam", "Kottayam",
                        "Kozhikode", "Malappuram", "Palakkad", "Pathanamthitta", "Thiruvananthapuram", "Thrissur",
                        "Wayanad"};
                break;
            case "TAMILNADU":
                villages = new String[]{"Ariyalur", "Chengalpattu", "Chennai", "Coimbatore", "Cuddalore",
                        "Dharmapuri", "Dindigul", "Erode", "Kallakurichi", "Kancheepuram",
                        "Kanyakumari", "Karur", "Krishnagiri", "Madurai", "Nagapattinam",
                        "Namakkal", "Nilgiris", "Perambalur", "Pudukkottai", "Ramanathapuram",
                        "Ranipet", "Salem", "Sivaganga", "Tenkasi", "Thanjavur",
                        "Theni", "Thoothukudi (Tuticorin)", "Tiruchirappalli", "Tirunelveli",
                        "Tirupathur", "Tiruppur", "Tiruvallur", "Tiruvannamalai", "Tiruvarur",
                        "Vellore", "Viluppuram", "Virudhunagar"};
                break;
            default:
                villages = new String[]{};
                break;
        }

        // Update the spinner for districts
        ArrayAdapter<String> districtAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, villages);
        districtAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        villageSpinner.setAdapter(districtAdapter);
    }
}
